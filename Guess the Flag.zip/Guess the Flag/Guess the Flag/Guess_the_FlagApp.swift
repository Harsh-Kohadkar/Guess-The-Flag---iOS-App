//
//  Guess_the_FlagApp.swift
//  Guess the Flag
//
//  Created by sanika chavan on 22/10/21.
//

import SwiftUI

@main
struct Guess_the_FlagApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
